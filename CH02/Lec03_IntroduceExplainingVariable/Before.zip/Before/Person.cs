namespace Refactoring
{
    public class Person
    {
        public string Country { get; set; }
        public string State { get; set; }
        public int Age { get; set; }
    }
}