namespace Refactoring
{
    public class Order
    {
        public double Quantity { get; set; }
        public double Price { get; set; }
    }
}