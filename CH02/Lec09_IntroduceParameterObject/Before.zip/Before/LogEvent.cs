﻿using System;

namespace Refactoring
{
    public class LogEvent
    {
        public string Data { get; set; }
        public DateTime Time { get; set; }
    }
}