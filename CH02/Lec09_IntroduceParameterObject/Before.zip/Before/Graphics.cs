﻿namespace Refactoring
{
    public class Graphics
    {
        public void SetStokeWidth(double width)
        {
        }

        public void DrawLine(double x1, double y1, double x2, double y2)
        {
        }
    }
}
